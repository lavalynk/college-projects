package Week07NetworkProgramming;

import java.net.*;
import java.io.*;

/**
 * Downloads a web page and saves it to a file.
 * @author Keith Brock
 * @version 1.0
 */
public class GetNetworkWebPage {

    /**
     * Retrieves web page content and writes it to a file.
     * @param args URL of the webpage (args[0]) and output filename (args[1]).
     */
    public static void main(String[] args) {
        // Validate input arguments
        if (args.length < 2) {
            System.out.println("Syntax error with url and filename. Usage: java GetNetworkWebPage <URL> <Filename>");
            return;
        }

        String urlString = args[0];
        String filePath = args[1];

        try {
            // Create URL object
            URL urlObj = new URL(urlString);
            URLConnection urlCon = urlObj.openConnection();

            // Read from URL
            InputStream inputStream = urlCon.getInputStream();
            BufferedInputStream reader = new BufferedInputStream(inputStream);
            BufferedOutputStream writer = new BufferedOutputStream(new FileOutputStream(filePath));

            // Read data into buffer and write to file
            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = reader.read(buffer)) != -1) {
                writer.write(buffer, 0, bytesRead);
            }

            // Close streams
            writer.close();
            reader.close();

            System.out.println("Web page successfully downloaded to " + filePath);

        } catch (MalformedURLException e) {
            System.out.println("The specified URL is malformed: " + urlString);
        } catch (IOException e) {
            System.out.println("An I/O error occurred: " + e.getMessage());
        }
    }
}
