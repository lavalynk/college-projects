package TestExceptions;

/**
 * Abstract: Demonstrates handling various types of exceptions.
 * @author Keith Brock
 * @version 1.0
 */
public class TestExceptions {

    /**
     * Main method: Calls other exception testing methods.
     */
    public static void main(String[] args) {
        testArithmeticError();
        testArrayIndexError();
        testNumberFormatError();
        testStringIndexError();
        testNullPointerError();
    }

    /**
     * Name: testArithmeticError
     * Abstract: Demonstrates handling an ArithmeticException (division by zero).
     */
    public static void testArithmeticError() {
        try {
            int intNum1 = 30;
            int intNum2 = 0;
            int output = intNum1 / intNum2; // This will cause an ArithmeticException
            System.out.println("Result: " + output);
        } catch (ArithmeticException e) {
            System.out.println("You should not divide a number by zero.");
        }
    }

    /**
     * Name: testArrayIndexError
     * Abstract: Demonstrates handling an ArrayIndexOutOfBoundsException.
     */
    public static void testArrayIndexError() {
        try {
            int[] aintNumbers = {1, 2, 3, 4, 5};
            System.out.println(aintNumbers[7]); // Accessing out-of-bounds index
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Array Index Out of Bounds.");
        }
    }

    /**
     * Name: testNumberFormatError
     * Abstract: Demonstrates handling a NumberFormatException.
     */
    public static void testNumberFormatError() {
        try {
            String strInvalidNumber = "ABC";
            int intParsedNumber = Integer.parseInt(strInvalidNumber); // This will cause NumberFormatException
            System.out.println("Parsed number: " + intParsedNumber);
        } catch (NumberFormatException e) {
            System.out.println("Number format exception occurred.");
        }
    }

    /**
     * Name: testStringIndexError
     * Abstract: Demonstrates handling a StringIndexOutOfBoundsException.
     */
    public static void testStringIndexError() {
        try {
            String strMessage = "Hello";
            char chrCharacter = strMessage.charAt(10); // Accessing an invalid index
            System.out.println("Character: " + chrCharacter);
        } catch (StringIndexOutOfBoundsException e) {
            System.out.println("String Index Out of Bound Exception.");
        }
    }

    /**
     * Name: testNullPointerError
     * Abstract: Demonstrates handling a NullPointerException.
     */
    public static void testNullPointerError() {
        try {
            String strMessage = null;
            int intLength = strMessage.length(); // This will cause NullPointerException
            System.out.println("String length: " + intLength);
        } catch (NullPointerException e) {
            System.out.println("Null Pointer Exception.");
        }
    }
}